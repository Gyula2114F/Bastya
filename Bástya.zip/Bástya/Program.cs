﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bástya
{
    class Program
    {
        static void Main()
        {
            int N = int.Parse(Console.ReadLine());
            char[][] tábla = new char[N][];

            for (int i = 0; i < N; i++)
            {
                tábla[i] = Console.ReadLine().ToCharArray();
            }

            string[] bemenet = Console.ReadLine().Split();
            int KS = int.Parse(bemenet[0]) - 1;
            int KO = int.Parse(bemenet[1]) - 1;
            int CS = int.Parse(bemenet[2]) - 1;
            int CO = int.Parse(bemenet[3]) - 1;

            int eredmény = MinLépés(tábla, KS, KO, CS, CO);
            Console.WriteLine(eredmény);
        }

        static int MinLépés(char[][] tábla, int KS, int KO, int CS, int CO)
        {
            Queue<int> várólista = new Queue<int>();
            int[][] irányok = { new int[] { -1, 0 }, new int[] { 1, 0 }, new int[] { 0, -1 }, new int[] { 0, 1 } };
            int N = tábla.Length;
            int[,] távolság = new int[N, N];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    távolság[i, j] = -1;
                }
            }

            várólista.Enqueue(KS * N + KO);
            távolság[KS, KO] = 0;

            while (várólista.Count > 0)
            {
                int most = várólista.Dequeue();
                int x = most / N;
                int y = most % N;

                if (x == CS && y == CO)
                {
                    return távolság[x, y];
                }

                for (int i = 0; i < 4; i++)
                {
                    for (int lépés = 1; ; lépés++)
                    {
                        int xx = x + irányok[i][0] * lépés;
                        int yy = y + irányok[i][1] * lépés;

                        if (xx < 0 || xx >= N || yy < 0 || yy >= N || tábla[xx][yy] == '+')
                        {
                            break;
                        }

                        if (távolság[xx, yy] == -1)
                        {
                            távolság[xx, yy] = távolság[x, y] + 1;
                            várólista.Enqueue(xx * N + yy);
                        }
                    }
                }
            }

            return -1;
        }
    }
}